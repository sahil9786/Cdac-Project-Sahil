
const HospitalRow = ({ hospital }) => {
 
  console.log(hospital)
    return(<tr>
        <td>{hospital.hid}</td>
        <td>{hospital.name}</td>
        <td>{hospital.address}</td>  
        <td>{hospital.phone}</td>  
      </tr>
    )
  }
  
  export default HospitalRow;
  