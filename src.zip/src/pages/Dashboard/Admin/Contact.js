import { render } from "@testing-library/react"

const Contact =()=>
{
   return(        <div className="table-agile-info">
   <div className="panel panel-default">
   <div className="panel-heading">
    Contact Details
   </div>
   <div>
     <table className="table" ui-jq="footable" ui-options='{
       "paging": {
         "enabled": true
       },
       "filtering": {
         "enabled": true
       },
       "sorting": {
         "enabled": true
       }}'>
       <thead>
         <tr>
           <th data-breakpoints="xs">ID</th>
           <th>User Name</th>
           <th>Email</th>
           <th>Mobile</th>
           <th>title</th>
          <th >Message</th>
          
         
           
         </tr>
       </thead>
       <tbody>
         <tr data-expanded="true">
           <td>1</td>
           <td>saurabh Jadhav</td>
           <td>S@gmail.com</td>
           <td>8999967626</td>
           <td>titleonafterprint</td>
           <td>Laboriosam exercitationem molestias beatae eos pariatur, similique, excepturi mollitia sit perferendis maiores ratione aliquam?</td>
         </tr>
         
        <tr data-expanded="true">
           <td>1</td>
           <td>saurabh Jadhav</td>
           <td>S@gmail.com</td>
           <td>8999967626</td>
           <td>titleonafterprint</td>
           <td>Laboriosam exercitationem molestias beatae eos pariatur, similique, excepturi mollitia sit perferendis maiores ratione aliquam?</td>
         </tr>
         
         <tr data-expanded="true">
           <td>1</td>
           <td>saurabh Jadhav</td>
           <td>S@gmail.com</td>
           <td>8999967626</td>
           <td>titleonafterprint</td>
           <td>Laboriosam exercitationem molestias beatae eos pariatur, similique, excepturi mollitia sit perferendis maiores ratione aliquam?</td>
         </tr>
         
         <tr data-expanded="true">
           <td>1</td>
           <td>saurabh Jadhav</td>
           <td>S@gmail.com</td>
           <td>8999967626</td>
           <td>titleonafterprint</td>
           <td>Laboriosam exercitationem molestias beatae eos pariatur, similique, excepturi mollitia sit perferendis maiores ratione aliquam?</td>
         </tr>
       </tbody>
     </table>
   </div>
   </div>
   </div>)
}
export default Contact;