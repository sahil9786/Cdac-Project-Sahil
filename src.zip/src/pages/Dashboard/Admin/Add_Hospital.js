import { render } from "@testing-library/react"
import { useState } from "react";
import axios from "axios";
import { url } from "../../../constants/url";
import { useHistory } from "react-router";
import { useEffect } from "react";

const Add_Hospital =()=>
{

    
    const history=useHistory();
    var result;
    const[name,setName]=useState("");
    const[address,setAddress]=useState("");
    const[phNo,setPhno]=useState("");
    const[email,setEmail]=useState("");
    const[password,setPassword]=useState("");


    function AddHosp(){
    
      const data={
        name : name,
        address : address,
        phone:phNo,
        user:{
            name:name,
            email:email,
            password:password
        }
      }
      axios.post(url + '/addhospital',data,{headers:{
        'Content-Type':"application/json",
        'Authorization':JSON.parse(localStorage.getItem('id'))
      }}).then((response) => {
        result = response.data
       if (result.status === 'success') {
         console.log(result.data)
         if(result.data===true){
             alert("Data Added SuccessFully")
             history.push('show_hospital')
         }
         else{
             alert("error")
         }
       }
       else {
         alert('error while loading list of doctors')
       } }
       )
    }

    return(
<div className="row">
                    <div className="col-lg-12">
                        <section className="panel">
                            <header className="panel-heading">
                                Add Hospitals
                                
                            </header>
                            <div className="panel-body">
                                <div className="form">
                                    <form className="cmxform form-horizontal ">
                                    {/* method="get" action="" */}
                                        <div className="form-group ">
                                            <label for="name" className="control-label col-lg-3">Hospital Name</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="name" onChange={(e)=>setName(e.target.value)} name="name" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="address" className="control-label col-lg-3">Address</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="address" name="address" onChange={(e)=>setAddress(e.target.value)} type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="phn" className="control-label col-lg-3">Pnone No</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " onChange={(e)=>setPhno(e.target.value)} id="phone" name="phone" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="email" className="control-label col-lg-3">Email</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " onChange={(e)=>setEmail(e.target.value)} id="email" name="email" type="email"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="photo" className="control-label col-lg-3">Photo</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="photo" name="photo" type="file"/>
                                            </div>
                                        </div>
                                        
                                        
                                        <div className="form-group ">
                                            <label for="email" className="control-label col-lg-3">Description</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="email" name="email" type="text"/>
                                            </div>
                                        </div>
                                        
                                        <div className="form-group ">
                                            <label for="password" className="control-label col-lg-3">Password</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " onChange={(e)=>setPassword(e.target.value)} id="password" name="password" type="password"/>
                                            </div>
                                        </div>
                                       
                                       
    
                                        <div className="form-group">
                                            <div className="col-lg-offset-3 col-lg-6">
                                                <input type="button" value="save" onClick={AddHosp}/>
                                               
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
    )
}
export default Add_Hospital;