// import { url } from '../commom/constants';
import axios from 'axios';
import { useState, useEffect } from 'react';
import './profile.css'
import { useHistory } from 'react-router';
const Profile = () => {
    let result=undefined;
    const history=useHistory();
    const [info,setInfo]=useState([]);
    const [thumbnail, setThumbnail] = useState(undefined);
    const [someVar, setSomeVar] = useState(false);

    // useEffect(() => {
    //     console.log("Profile component got loaded")
    //     axios.get(url + '/myprofile',{headers:{
    //         'Content-Type':"application/json",
    //         'Authorization':JSON.parse(localStorage.getItem('id'))
    //       }}).then((response) => {
    //         result = response.data
    //         if (result.status === 'success') 
    //         {
    //             setInfo(result.data)
    //             console.log(result.data)
    //         } 
    //         else 
    //         alert('error while loading list of albums')
    //       })
    //   }, [someVar])

    // const data=new FormData();

    // const onFileSelect = (event) => {
    //     setThumbnail(event.target.files[0])

    //   }
    //   const Edit=()=>{
    //       history.push('edit')
    //   }

    //   const upload = () => {
    //     data.append('thumbnail',thumbnail)
    //     axios.post(url + '/changephoto',data,{headers:{
    //         'Content-Type':"application/json",
    //         'Authorization':JSON.parse(localStorage.getItem('id'))
    //       }}).then((response) => {
    //         const result1 = response.data
    //         if (result1.status === 'success') {
    //             console.log(result1)
    //             console.log('render');
    //             if(someVar===false)
    //             setSomeVar(true);
    //             else
    //             setSomeVar(false);
    //         } else {
    //             alert('error while loading list of albums')
    //         }
    //       })
    //   }
    //   console.log(info.thumbnail)
    // 
    return(<>
    <div className="container emp-profile">
            <form method="post">
                <div className="row">
                    <div className="col-md-4">
                        <div className="profile-img" style={{height:`15vw`,width:`20vw`}}>
                            {/* <img  src={url + '/' + info.thumbnail}/> */}
                        </div>
                        <div>                       
                                <label htmlFor=""></label>
                                <input
                                accept="image/*"
                                
                                type="file"
                                className="form-control"
                                />
                            </div>
                            <br />
                            <div>
                            <input type="button" className="btn-light" value="change photo"  style={{height:`3vw`,width:`10vw`}}/>
                            </div>
                    </div>
                    <div className="col-md-6">
                        <div className="profile-head">
                                    <h5>
                                        {/* {info.name} */}name
                                    </h5>
                                    <h6>
                                        {/* {info.role} */}role
                                    </h6>
                                    <br />
                            <ul className="nav nav-tabs" id="myTab" role="tablist">
                                <li className="nav-item">
                                    <a className="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                            </ul>
                            <div className="col-md-8">
                        <div className="tab-content profile-tab" id="myTabContent">
                            <div className="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>User Id</label>
                                            </div>
                                            <div className="col-md-6">
                                                <p>userid</p>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>Name</label>
                                            </div>
                                            <div className="col-md-6">
                                                <p>name</p>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>Email</label>
                                            </div>
                                            <div className="col-md-6">
                                                <p>abc@gmail.com</p>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-6">
                                                <label>Phone</label>
                                            </div>
                                            <div className="col-md-6">
                                                <p>12321323</p>
                                            </div>
                                        </div>           
                            </div>
                           
                        </div>
                    </div>
                        </div>
                    </div>
                    <div className="col-md-2">
                        <input type="submit" className="profile-edit-btn" name="btnAddMore"  value="Edit Profile"/>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-4">
                    </div>
                  
                </div>
            </form>           
        </div>
    </>
  )}
  
  export default Profile
  