import axios from 'axios'
import { useState, useEffect } from 'react'
import { url } from '../../../constants/url';
import DoctorRow from './doctorRow';


const Dr_Detail = () => {
  
  let result;
  const [Doctors, setDoctors] = useState([])
  
  useEffect(() => {
    console.log(`Doctor Details component got loaded`)
    getDoctors()
  }, [])
  
  const getDoctors = () => { 
    axios.get(url + '/doctorlist',{headers:{
      'Content-Type':"application/json",
      'Authorization':JSON.parse(localStorage.getItem('id'))
    }}).then((response) => {
       result = response.data
      if (result.status === 'success') {
        setDoctors(result.data)
        console.log(result.data)
      }
      else {
        alert('error while loading list of doctors')
      } }
      )
    }
  return (<>
  <div className="table-agile-info">
    <div className="panel panel-default">
    <div className="panel-heading">
     View Doctors
    </div>
    <div>
      <table className="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
          <th>did</th>
      <th>name</th>
      <th>mobile</th>
      <th>specialization</th>
      <th>email</th>
      <th>password</th>
      <th>hid</th> 
          </tr>
        </thead>
        <tbody>
        {
            Doctors.map((doctor)=>{
              return <DoctorRow key={doctor.did} doctor={doctor} />
            })
          }
        </tbody>
      </table>
    </div>
    </div>
    </div>
  </>)
}

export default Dr_Detail
