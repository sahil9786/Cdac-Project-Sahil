import { render } from "@testing-library/react"
import axios from "axios";
import { useEffect } from "react";
import { url } from "../../../constants/url";
import { useState } from "react";
import HospitalRow from "./hospitalRow";

const Show_Hospital=()=>{
  
    
  let result;
  const [Hospital, setHospital] = useState([])
  
  useEffect(() => {
    console.log(`Hospital Details component got loaded`)
    getHospitals()
  }, [])
  
  const getHospitals = () => { 
    axios.get(url + '/hospitallist',{headers:{
      'Content-Type':"application/json",
      'Authorization':JSON.parse(localStorage.getItem('id'))
    }}).then((response) => {
       result = response.data
      if (result.status === 'success') {
        setHospital(result.data)
        console.log(result.data)
      }
      else {
        alert('error while loading list of Hospitals')
      } }
      )
    }
  return (<>
  <div className="table-agile-info">
    <div className="panel panel-default">
    <div className="panel-heading">
     View Hospital
    </div>
    <div>
      <table className="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
          <th>hid</th>
      <th>name</th>
      <th>address</th>
      <th>phNo</th>    </tr>
        </thead>
        <tbody>
        {
            Hospital.map((hospital)=>{
              return <HospitalRow key={hospital.hid} hospital={hospital} />
            })
          }
        </tbody>
      </table>
    </div>
    </div>
    </div>
  </>)
}

export default Show_Hospital;