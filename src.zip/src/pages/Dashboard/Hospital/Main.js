import React from "react";
import { BrowserRouter,Route, Link, Switch } from "react-router-dom";
import { Redirect } from "react-router";
import Add_Dr from "./Add_Dr";
import Show_Dr from "./Show_Dr";
import Add_Receprion from "./Add_Reception";
import Show_Reception from "./Show_Reception";
import Patient_History from "./Patient_History";
import Patient_Bill from "./Patient_Bill";
import Appointment_Detail from "./Appointment_Detail";
import Profile from "./Profile";

const HospitalMain=()=>{
    
    return(
            <BrowserRouter>
            <div>
            <header className="header fixed-top clearfix">

<div className="brand">
    <a href="#" className="logo">
        Hospital
    </a>
    <div className="sidebar-toggle-box">
        <div className="fa fa-bars"></div>
    </div>
</div>

<div className="top-nav clearfix">

    <ul className="nav pull-right top-menu">
       

        <li className="dropdown">
            <a data-toggle="dropdown" className="dropdown-toggle" href="#">
                <img alt="" src="images/2.png"/>
                <span className="username">John Doe</span>
                <b className="caret"></b>
            </a>
            <ul className="dropdown-menu extended logout">
               
                
                <li><Link to="/home"><i className="fa fa-key"></i> Log Out</Link></li>
            </ul>
        </li>

       
    </ul>

</div>
</header>


<aside>
    <div id="sidebar" className="nav-collapse">

        <div className="leftside-navigation">
<ul className="sidebar-menu" id="nav-accordion">
                <li>
                    <a className="active" href="#">
                        <i className="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li className="sub-menu">
                    <a href="javascript:;">
                        <i className="fa fa-book"></i>
                        <span>Doctor Details</span>
                    </a>
                    <ul className="sub">
						<li><Link to="/add_dr">Add Doctor</Link></li>
						<li><Link to="/show_dr">Doctor List</Link></li>
                       
                    </ul>
                </li>
				
				<li className="sub-menu">
                    <a href="javascript:;">
                        <i className="fa fa-book"></i>
                        <span>Reception Details</span>
                    </a>
                    <ul className="sub">
						<li><Link to="/add_reception">Add Receptionist</Link></li>
						<li><Link to="/show_reception">Receptionist detail</Link></li>
                       
                    </ul>
                </li>
				
				
				<li className="sub-menu">
                    <a href="javascript:;">
                        <i className="fa fa-book"></i>
                        <span>Patient Details</span>
                    </a>
                    <ul className="sub">
						<li><Link to="/patient_history">Patient History</Link></li>
						<li><Link to="patient_bill">Patient Bill</Link></li>
                       
                    </ul>
                </li>
                <li>
                    <Link to="/appointment_detail">
                        <i className="fa fa-bullhorn"></i>
                        <span>Patient Appointment Details</span>
                    </Link>
                </li>
				<li>
                    <Link to="/profile">
                        <i className="fa fa-bullhorn"></i>
                        <span>Update Profile</span>
                    </Link>
                </li>
				</ul>            </div>

    </div>
</aside>
           <div> 
<Switch>
<Route exact path="/"><Redirect to="/add_dr" /></Route>
	<Route exact path="/add_dr"component={Add_Dr}></Route>
	<Route exact path="/show_dr"component={Show_Dr}></Route>
	<Route exact path="/add_reception"component={Add_Receprion}></Route>
	<Route exact path="/show_reception"component={Show_Reception}></Route>
	<Route exact path="/patient_history"component={Patient_History}></Route>
	<Route exact path="/patient_bill"component={Patient_Bill}></Route>
	<Route exact path="/appointment_detail"component={Appointment_Detail}></Route>
   <Route exact path="/profile"component={Profile}></Route> 
</Switch>

	</div>

    
            </div>
            </BrowserRouter>
        )
        
            

        
    }

export default HospitalMain;