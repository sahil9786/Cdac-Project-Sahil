import axios from "axios";
import { url } from "../constants/url";
import { useState } from "react";

const Register=()=>{
  
	let result;
	const [name,setName] = useState("");
	const [email,setEmail] = useState("");
	const [password,setPassword] = useState("");
	
	const RegisterUser = () => {
		const data={
			name : name,
			email:email,
			password:password
		  }
		  console.log(password)
	  axios.post(url + '/register',data,{headers:{
		'Content-Type':"application/json",
		'Authorization':JSON.parse(localStorage.getItem('id'))
	  }}).then((response) => {
		 result = response.data
		if (result.status === 'success') {
		  console.log(result.data)
		}
		else {
		  alert('error')
		} }
		)
	  }
	
    return(<>

    <div>


    <div class="reg-w3">
<div class="w3layouts-main">
	<h2>Register Now</h2>
		<form action="#" method="post">
			<input type="text" class="ggg" onChange={(e)=>setName(e.target.value)} name="Name" placeholder="NAME" required=""/>
			<input type="email" class="ggg" onChange={(e)=>setEmail(e.target.value)} name="Email" placeholder="E-MAIL" required=""/>
			<input type="text" class="ggg" name="Phone" placeholder="PHONE" required=""/>
			<input type="text" class="ggg" name="address" placeholder="Address" required=""/>
			<input type="text" class="ggg" name="adhar" placeholder="Adhar No" required=""/>
			<input type="password" class="ggg" name="password" onChange={(e)=>setPassword(e.target.value)}  placeholder="password" required=""/>
			<label>Upload Photo</label>
			<input type="file" class="ggg" name="photo"  required=""/>
				<div class="clearfix"></div>
				<input type="button" value="submit" name="register" onClick={RegisterUser}/>
		</form>
		
</div>
</div>
<script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
    </div>
    </>)
}

export default Register;