const Appointment=()=>
{
    return(
        <>
        <div>
          <section id="main-content">
        <section className="wrapper">
		
		
        <div className="table-agile-info">
<div className="panel panel-default">
<div className="panel-heading">
Appointment Status    
</div>
<div className="table-responsive">
  <table className="table" ui-jq="footable" ui-options='{
    "paging": {
      "enabled": true
    },
    "filtering": {
      "enabled": true
    },
    "sorting": {
      "enabled": true
    }}'>
    <thead>
      <tr>
        <th data-breakpoints="xs">ID</th>
        <th>Patient Name</th>
        <th>Mobile</th>
        <th>Hospital Name</th>
        <th>Dr Name</th>
        <th>Timestamp</th>
        <th>Status</th>

        
      </tr>
    </thead>
    <tbody>
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>Minakshi Hospital</td>
        <td>Dr. Bhosale S. V.</td>
        <td>2038-01-19 03:14:07</td>
        
        <td>Approve</td>
        
      </tr>
      
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>Minakshi Hospital</td>
        <td>Dr. Bhosale S. V.</td>
        <td>2038-01-19 03:14:07</td>
        
        <td>Approve</td>
        
      </tr>
      
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>Minakshi Hospital</td>
        <td>Dr. Bhosale S. V.</td>
        <td>2038-01-19 03:14:07</td>
        
        <td>Approve</td>
        
      </tr>
      
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>Minakshi Hospital</td>
        <td>Dr. Bhosale S. V.</td>
        <td>2038-01-19 03:14:07</td>
        
        <td>Approve</td>
        
      </tr>
    </tbody>
  </table>
</div>
</div>
</div>
    
    
    
        

</section>
<div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>


        </div>
        </>
    )
}
export default Appointment;