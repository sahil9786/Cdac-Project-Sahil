import { render } from "@testing-library/react"

const Show_Service =()=>{
  
    return( <div className="table-agile-info">
    <div className="panel panel-default">
    <div className="panel-heading">
     View Doctor
    </div>
    <div>
      <table className="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">ID</th>
            <th>Doctor Name</th>
            <th>Mobile</th>
            <th>Specialization</th>
            <th>email</th>
            <th>Photo</th>
           
           
            <th data-breakpoints="xs sm md" data-title="DOB">Password</th>
            
          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            <td>Saurabh Jadhav</td>
            <td>8999967626</td>
            <td> Orthopedic</td>
            <td>dr@gmail.com</td>
            
            <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
            <td>wertzs</td>
            
          </tr>
          
         <tr data-expanded="true">
            <td>1</td>
            <td>Saurabh Jadhav</td>
            <td>8999967626</td>
            <td> Orthopedic</td>
            <td>dr@gmail.com</td>
            
            <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
            <td>wertzs</td>
            
          </tr>
          
          <tr data-expanded="true">
            <td>1</td>
            <td>Saurabh Jadhav</td>
            <td>8999967626</td>
            <td> Orthopedic</td>
            <td>dr@gmail.com</td>
            
            <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
            <td>wertzs</td>
            
          </tr>
          
          <tr data-expanded="true">
            <td>1</td>
            <td>Saurabh Jadhav</td>
            <td>8999967626</td>
            <td> Orthopedic</td>
            <td>dr@gmail.com</td>
            
            <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
            <td>wertzs</td>
            
          </tr>
            
          
        </tbody>
      </table>
    </div>
    </div>
    </div>)

}
export default Show_Service;