
const DoctorRow = ({ doctor }) => {
 
  
    return(<tr>
        <td>{doctor.did}</td>
        <td>{doctor.name}</td>
        <td>{doctor.mobile}</td>  
        <td>{doctor.specialization}</td>
        <td>{doctor.email}</td>
        <td>{doctor.password}</td>
        <td>{doctor.hid}</td>
      </tr>
    )
  }
  
  export default DoctorRow;
  