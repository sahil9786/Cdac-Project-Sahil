
const PatientRow = ({ patient }) => {
 
  
    return(<tr>
        <td>{patient.pid}</td>
        <td>{patient.name}</td>
        <td>{patient.address}</td>  
        <td>{patient.mobile}</td>
      </tr>
    )
  }
  
  export default PatientRow;
  