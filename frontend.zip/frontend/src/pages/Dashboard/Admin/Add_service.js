import { render } from "@testing-library/react"

const Add_service =()=>
{
    return(<div className="row">
                    <div className="col-lg-12">
                        <section className="panel">
                            <header className="panel-heading">
                                Add Services
                                
                            </header>
                            <div className="panel-body">
                                <div className="form">
                                    <form className="cmxform form-horizontal " id="signupForm" method="get" action="" novalidate="novalidate">
                                        <div className="form-group ">
                                            <label for="name" className="control-label col-lg-3">Service Title</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="title" name="title" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="address" className="control-label col-lg-3">Description</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="des" name="des" type="text"/>
                                            </div>
                                        </div>
                                        
                                        <div className="form-group ">
                                            <label for="photo" className="control-label col-lg-3">Photo</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="photo" name="photo" type="file"/>
                                            </div>
                                        </div>
                                        
                                        
                                        
                                       
                                       
    
                                        <div className="form-group">
                                            <div className="col-lg-offset-3 col-lg-6">
                                                <button className="btn btn-primary" type="submit">Save</button>
                                               
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>)
}
export default Add_service;
