import React from "react";
import { BrowserRouter,Route, Link, Switch } from "react-router-dom";
import { Redirect } from "react-router";
import Add_Hospital from "./Add_Hospital";
import Show_Hospital from "./Show_Hospital";
import Patient_Detail from "./Patient_Detail";
import Dr_Detail from "./Dr_detail";
import Add_Service from "./Add_service";
import Show_Service from "./Show_Service";
import Profile from "./Profile";
import Contact from "./Contact";

const AdminMain=()=>{
    return (<>
        <BrowserRouter><div className="container-fluid">
        <div className="row flex-nowrap">
            <div className="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light dash-profile" style={{fontSize:'18px',color:'black'}}>
                <div className="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <h5 style={{color:'black'}}>Hello</h5>
                    <ul className="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li className="nav-item">
                    <Link style={{color:'black'}} className="nav-link" to="/profile">
                         Profile
                       </Link>
                        </li>
     
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/add_hospital">
                            Add Hospital
                       </Link>
                        </li>
     
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/show_hospital">
                            Show Hospital
                       </Link>
                        </li>
     
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/patient_detail">
                            Patient Details
                       </Link>
                        </li>
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/dr_Detail">
                         Doctor Details
                       </Link>
                        </li>
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/add_service">
                            Add Service
                       </Link>
                        </li>
     
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/show_service">
                            Show Service
                       </Link>
                        </li>
                        <li className="nav-item">
                            <Link style={{color:'black'}} className="nav-link" to="/contact">
                            Show contact
                       </Link>
                        </li>
     
                    </ul>
                    <hr />
                </div>
            </div>
            <div className="col py-3">
            <Switch>
            	<Route exact path="/add_hospital" component={Add_Hospital}></Route>
                <Route exact path="/show_hospital" component={Show_Hospital}></Route>
                <Route exact path="/patient_detail" component={Patient_Detail}></Route>
 	            <Route exact path="/dr_detail" component={Dr_Detail}></Route>
 	            <Route exact path="/add_service" component={Add_Service}></Route>
 	            <Route exact path="/show_service" component={Show_Service}></Route>
 	            <Route exact path="/profile" component={Profile}></Route>
                <Route exact path="/contact" component={Contact}></Route> 

                
               </Switch>
            </div>
        </div>
     </div>
     </BrowserRouter>
     </>)
//         return(
//             <BrowserRouter>
//             <div>
//             <header className="header fixed-top clearfix">

// <div className="brand">
//     <a href="#" className="logo">
//         ADMIN
//     </a>
//     <div className="sidebar-toggle-box">
//         <div className="fa fa-bars"></div>
//     </div>
// </div>

// <div className="top-nav clearfix">
//     <ul className="nav pull-right top-menu">
       
      
//         <li className="dropdown">
//             <a data-toggle="dropdown" className="dropdown-toggle" href="#">
//                 <img alt="" src="images/2.png"/>
//                 <span className="username">John Doe</span>
//                 <b className="caret"></b>
//             </a>
//             <ul className="dropdown-menu extended logout">
               
                
//                 <li><Link to="/home"><i className="fa fa-key"></i> Log Out</Link></li>
//             </ul>
//         </li>
        
       
//     </ul>
   
// </div>
// </header>

// <aside>
//     <div id="sidebar" className="nav-collapse">
        
//         <div className="leftside-navigation">
//             <ul className="sidebar-menu" id="nav-accordion">
//                 <li>
//                     <a className="active" href="#">
//                         <i className="fa fa-dashboard"></i>
//                         <span>Dashboard</span>
//                     </a>
//                 </li>
                
//                 <li className="sub-menu">
//                     <a href="javascript:;">
//                         <i className="fa fa-book"></i>
//                         <span>Hospital Details</span>
//                     </a>
//                     <ul className="sub">
// 						<li><Link to="/add_hospital">Add Hospital</Link></li>
// 						<li><Link to="/show_hospital">Hospital List</Link></li>
                       
//                     </ul>
//                 </li>
//                 <li>
//                     <Link to="/patient_detail">
//                         <i className="fa fa-bullhorn"></i>
//                         <span>Patient Details </span>
//                     </Link>
//                 </li>
				
// 				<li>
//                     <Link to="/dr_detail">
//                         <i className="fa fa-bullhorn"></i>
//                         <span>Doctor Details </span>
//                     </Link>
//                 </li>
                
//                 <li className="sub-menu">
//                     <a href="javascript:;">
//                         <i className="fa fa-tasks"></i>
//                         <span>Services</span>
//                     </a>
//                     <ul className="sub">
//                        <li><Link to="/add_service">Add Services</Link></li>
//                         <li>< Link to="show_service">Show Services</Link></li>
						
//                     </ul>
//                 </li>
// 				<li>
//                     <Link to="/profile">
//                         <i className="fa fa-bullhorn"></i>
//                         <span>Edit Profile</span>
//                     </Link>
//                 </li>
//                 <li>
//                     <Link to="/contact">
//                         <i className="fa fa-bullhorn"></i>
//                         <span>Contact Details </span>
//                     </Link>
//                 </li>
                
               
               
                
//             </ul>      </div>      </div>
        
// </aside>
//            <div> 
// <Switch>
// <Route exact path="/"><Redirect to="/add_hospital" /></Route>
// 	<Route exact path="/add_hospital"component={Add_Hospital}></Route>
// 	<Route exact path="/show_hospital"component={Show_Hospital}></Route>
// 	<Route exact path="/patient_detail"component={Patient_Detail}></Route>
// 	<Route exact path="/dr_detail"component={Dr_Detail}></Route>
// 	<Route exact path="/add_service"component={Add_Service}></Route>
// 	<Route exact path="/show_service"component={Show_Service}></Route>
// 	<Route exact path="/profile"component={Profile}></Route>
//    <Route exact path="/contact"component={Contact}></Route> 
   
// </Switch>

// 	</div>

  
//             </div>
//             </BrowserRouter>
//         )
        
            

        
//     }
                }

export default AdminMain;