import { render } from "@testing-library/react"

const Bill=()=>{
    return(<> 
    <div>
        <section id="main-content">
    <section className="wrapper">
		
        <div className="form-w3layouts">
               
             
                <div className="row">
                    <div className="col-lg-12">
                        <section className="panel">
                            <header className="panel-heading">
                                Making Bill
                                
                            </header>
                            <div className="panel-body">
                                <div className="form">
                                    <form className="cmxform form-horizontal " id="signupForm" method="get" action="" novalidate="novalidate">
                                        <div className="form-group ">
                                            <label for="id" className="control-label col-lg-3">Patient ID</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="id" name="id" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="name" className="control-label col-lg-3">Patient Name</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="name" name="name" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="mob" className="control-label col-lg-3">Mobile</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="mob" name="mob" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="date" className="control-label col-lg-3">Date</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="date" name="date" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="health" className="control-label col-lg-3">Health Issue</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="health" name="health" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="medicine" className="control-label col-lg-3">Medicine</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="medicine" name="medicine" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="bill" className="control-label col-lg-3">Bill AMT</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="bill" name="bill" type="text"/>
                                            </div>
                                        </div>
                                        
                                       
                                       
    
                                        <div className="form-group">
                                            <div className="col-lg-offset-3 col-lg-6">
                                                <button className="btn btn-primary" type="submit">Save</button>
                                               
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            
            
            
                
        
    </section>
    <div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>
    </div>
    </>)
}
export default Bill;