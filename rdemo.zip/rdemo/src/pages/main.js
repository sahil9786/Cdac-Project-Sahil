import React from "react";
import { BrowserRouter,Route, Link, Switch } from "react-router-dom";
import { Redirect } from "react-router";

import Home from "./Home";
import About1 from "./About copy";
import Contact from "./Contact";
import Appointment from "./appointment";
import Department from "./Department";
import Service from "./Service";
import Doctor from "./Doctor";
 import Login from "./Login"; 
 import Register from "./Register";
import AdminMain from "./Dashboard/Admin/Main";
import DoctorMain from "./Dashboard/Doctor/Main";
import HospitalMain from "./Dashboard/Hospital/Main";
import PatientMain from "./Dashboard/Patient/Main";
import ReceptionMain from "./Dashboard/Reception/Main";
 



 const Main=()=>{
    
        return(
			<BrowserRouter>
			<div>
        <div>
            <header style={{backgroundColor: "white"}} >
	<div className="header-top-bar">
		<div className="container" >
			<div className="row align-items-center">
				<div className="col-lg-6">
					<ul className="top-bar-info list-inline-item pl-0 mb-0">
						<li className="list-inline-item"><a href="mailto:support@gmail.com"><i className="icofont-support-faq mr-2"></i>support@novena.com</a></li>
						<li className="list-inline-item"><i className="icofont-location-pin mr-2"></i>Address Ta-134/A, New York, USA </li>
					</ul>
				</div>
				<div className="col-lg-6">
					<div className="text-lg-right top-right-bar mt-2 mt-lg-0">
						<a href="tel:+23-345-67890" >
							<span>Call Now : </span>
							<span className="h4">823-4565-13456</span>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav className="navbar navbar-expand-lg navigation" id="navbar">
		<div className="container">
		 	 <a className="navbar-brand" href="#">
			  	<img src="assets/images/logo.png" alt="" className="img-fluid" />
			  </a>

		  	<button className="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarmain" aria-controls="navbarmain" aria-expanded="false" aria-label="Toggle navigation">
			<span className="icofont-navigation-menu"></span>
		  </button>

		  <div className="collapse navbar-collapse" id="navbarmain">
			<ul className="navbar-nav ml-auto">
			  <li className="nav-item active">
				<Link className="nav-link" to="/home">Home</Link>
			  </li>
			   <li className="nav-item"><Link className="nav-link" to="/about">About</Link></li>
			    <li className="nav-item"><Link className="nav-link" to="/service">Services</Link></li>
				<li className="nav-item"><Link className="nav-link" to="/department">Departments</Link></li>
				<li className="nav-item"><Link className="nav-link" to="/doctor">Doctors</Link></li>
				<li className="nav-item"><Link className="nav-link" to="/appointment">Appoinment</Link></li>
				<li className="nav-item"><Link className="nav-link" to="/contact">Contact</Link></li>
				 <li className="nav-item"><Link className="nav-link" to="/login">Login</Link></li> 
				 <li className="nav-item"><Link className="nav-link" to="/register">Register</Link></li>
			</ul>
		  </div>
		</div>

	</nav>
</header>
	<div>
<Switch>
<Route exact path="/"><Redirect to="/home" /></Route>
	<Route exact path="/home"component={Home}></Route>
	<Route exact path="/about"component={About1}></Route>
	<Route exact path="/contact" component={Contact}></Route>
	<Route exact path="/appointment" component={Appointment}></Route>
	<Route exact path="/department"component={Department}></Route>
	<Route exact path="/service"component={Service}></Route>
	<Route exact path="/doctor"component={Doctor}></Route>
   <Route exact path="/login"component={Login}></Route> 
   <Route exact path="/register"component={Register}></Route>
   <Route exact path="/adminlogin"component={AdminMain}></Route> 
   <Route exact path="/doctorlogin"component={DoctorMain}></Route> 
   <Route exact path="/hospitallogin"component={HospitalMain}></Route> 
   <Route exact path="/patientlogin"component={PatientMain}></Route> 
   <Route exact path="/receptionlogin"component={ReceptionMain}></Route> 
</Switch>

	</div>



<footer className="footer section gray-bg">
	<div className="container">
		
		
		<div className="footer-btm py-4 mt-5">
			<div className="row align-items-center justify-content-between">
				<div className="col-lg-12">
					<div className="copyright">
						&copy; Copyright Reserved to <span className="text-color">IACSD Akurdi</span> 
					</div>
				</div>
				
			</div>

			<div className="row">
				<div className="col-lg-4">
					<a className="backtop js-scroll-trigger" href="#top">
						<i className="icofont-long-arrow-up"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
</footer>
   

    
    <script src="assets/plugins/jquery/jquery.js"></script>
   
    <script src="assets/plugins/bootstrap/js/popper.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/plugins/counterup/jquery.easing.js"></script>
    
    <script src="assets/plugins/slick-carousel/slick/slick.min.js"></script>
   
    <script src="assets/plugins/counterup/jquery.waypoints.min.js"></script>
    
    <script src="assets/plugins/shuffle/shuffle.min.js"></script>
    <script src="assets/plugins/counterup/jquery.counterup.min.js"></script>
 
    <script src="assets/plugins/google-map/map.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkeLMlsiwzp6b3Gnaxd86lvakimwGA6UA&callback=initMap"></script>    
    
    <script src="assets/js/script.js"></script>
    <script src="assets/js/contact.js"></script>

			
		</div>
		
		
       </div>
		</BrowserRouter>);
    }


export default Main;