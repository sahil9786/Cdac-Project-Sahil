import { useState } from "react";
import axios from "axios";
import { url } from "../constants/url";
import { useHistory } from "react-router";

const Login = () => {
  let result=undefined;
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
//  const[data,setdata]=([])
  const history=useHistory();

  function Forgot(){
    history.push('/forgot')
  }

  function SignIn(){
    console.log(email,password);
  const data={
    username : email,
    password : password
  }
  axios.post(url+"/authenticate",data,{
    headers:{
      'Content-Type':"application/json"
    }
  }).then((response) => {
    result = response.data
    if(result.status==='success'){
      localStorage.setItem('id',JSON.stringify("Bearer "+result.data.jwt))  
      return axios.get(url+"/getrole",{
        headers:{
          'Content-Type':"application/json",
          'Authorization':JSON.parse(localStorage.getItem('id'))
        }
      }).then((response) => {
        result = response.data
        console.log(result)
        if(result.status==='error')
        alert('User Not Found')
        else{
         //result=localStorage.getItem('id')  
        if(result.data.role==="admin"){
        history.push({
          pathname : '/adminlogin',
          state : {result:result.data}
          })        
        }
        else if(result.data.role==="doctor"){
          history.push({
            pathname : '/doctorlogin',
            state : {result:result.data}
            })        
          }
        else if(result.data.role==="hospital"){
            history.push({
				pathname : '/hospitallogin',
              state : {result:result.data}
              })        
            }
		else if(result.data.role==="patient"){
				history.push({
					pathname : '/patientlogin',
				  state : {result:result.data}
				  })        
				}
        else if(result.data.role==="reception"){
          history.push({
            pathname : '/receptionlogin',
            state : {result:result.data}
            })        
          }
      }
      })
    }
    else
    alert('Invalid Credintials')
  })
  
  }
  
  return (<>
    <center>
      <br />
      <br />
  <div className="login-profile ">
    <h1 style={{color:'white'}} >LOGIN </h1>
    <br />
  <div className="col-xs-3">
    <input type="email" className="form-control" id="email" onChange={(e)=>setEmail(e.target.value)} placeholder="Enter Email Id" required/>
  </div>
  <br />
  <div className="col-xs-3">
    <input type="password" className="form-control" id="password" onChange={(e)=>setPassword(e.target.value)} placeholder="Enter Password" required/>
  </div>
  <br />

  <div className="col-12">
    <button className="btn btn-danger" style={{backgroundColor:'red'}} type="button" onClick={SignIn}>Sign in</button> <br/>
    <div style={{height:`0.7vw`}}></div>
  </div>
</div>
</center>
</>)
  }

export default Login
