import { render } from "@testing-library/react"
import { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import { url } from "../../../constants/url";
import PatientRow from "./patientRow";

const Patient_detail=()=>{

  let result;
  const [Patients, setPatients] = useState([])
  
  useEffect(() => {
    console.log(`Patients Details component got loaded`)
    getPatients()
  }, [])
  
  const getPatients = () => { 
    axios.get(url + '/patientlist',{headers:{
      'Content-Type':"application/json",
      'Authorization':JSON.parse(localStorage.getItem('id'))
    }}).then((response) => {
       result = response.data
      if (result.status === 'success') {
        setPatients(result.data)
        console.log(result.data)
      }
      else {
        alert('error while loading list of patients')
      } }
      )
    }
  return (<>
  <div className="table-agile-info">
    <div className="panel panel-default">
    <div className="panel-heading">
     View Doctors
    </div>
    <div>
      <table className="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
          <th>pid</th>
      <th>name</th>
      <th>address</th>
      <th>mobile</th>
          </tr>
        </thead>
        <tbody>
        {
            Patients.map((patient)=>{
              return <PatientRow key={patient.pid} patient={patient} />
            })
          }
        </tbody>
      </table>
    </div>
    </div>
    </div>
  </>)
}

  
    // return(<div className="table-agile-info">
    // <div className="panel panel-default">
    // <div className="panel-heading">
    //  View Patient
    // </div>
    // <div>
    //   <table className="table" ui-jq="footable" ui-options='{
    //     "paging": {
    //       "enabled": true
    //     },
    //     "filtering": {
    //       "enabled": true
    //     },
    //     "sorting": {
    //       "enabled": true
    //     }}'>
    //     <thead>
    //       <tr>
    //         <th data-breakpoints="xs">ID</th>
    //         <th>Patient Name</th>
    //         <th>Mobile</th>
    //         <th>Address</th>
    //         <th>Adhar No</th>
    //         <th>Photo</th>
           
           
    //         <th data-breakpoints="xs sm md" data-title="DOB">Password</th>
            
    //       </tr>
    //     </thead>
    //     <tbody>
    //       <tr data-expanded="true">
    //         <td>1</td>
    //         <td>Saurabh Jadhav</td>
    //         <td>8999967626</td>
    //         <td> SATARA</td>
    //         <td>9876565432458765</td>
            
    //         <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
    //         <td>wertzs</td>
            
    //       </tr>
          
    //       <tr data-expanded="true">
    //         <td>1</td>
    //         <td>Saurabh Jadhav</td>
    //         <td>8999967626</td>
    //         <td> SATARA</td>
    //         <td>9876565432458765</td>
            
    //         <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
    //         <td>wertzs</td>
            
    //       </tr>
          
    //       <tr data-expanded="true">
    //         <td>1</td>
    //         <td>Saurabh Jadhav</td>
    //         <td>8999967626</td>
    //         <td> SATARA</td>
    //         <td>9876565432458765</td>
            
    //         <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
    //         <td>wertzs</td>
            
    //       </tr>
          
    //       <tr data-expanded="true">
    //         <td>1</td>
    //         <td>Saurabh Jadhav</td>
    //         <td>8999967626</td>
    //         <td> SATARA</td>
    //         <td>9876565432458765</td>
            
    //         <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
            
    //         <td>wertzs</td>
            
    //       </tr>
    //     </tbody>
    //   </table>
    // </div>
    // </div>
    // </div>)

export default Patient_detail;