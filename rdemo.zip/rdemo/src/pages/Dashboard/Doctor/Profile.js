const Profile=()=>{
    return(<> 
    <div>
      <section id="main-content">
    <section className="wrapper">
		
		
        <div className="table-agile-info">
<div className="panel panel-default">
<div className="panel-heading">
 View Profile
</div>
<div>
  <table className="table" ui-jq="footable" ui-options='{
    "paging": {
      "enabled": true
    },
    "filtering": {
      "enabled": true
    },
    "sorting": {
      "enabled": true
    }}'>
    <thead>
      <tr>
        <th data-breakpoints="xs">ID</th>
        <th>Name</th>
        <th>Mobile</th>
       
        <th>email</th>
        <th>Photo</th>
       
       
        <th data-breakpoints="xs sm md" data-title="DOB">Password</th>
        <th>Actions</th>
        
      </tr>
    </thead>
    <tbody>
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
      
        <td>dr@gmail.com</td>
        
        <td><img src="images/g2.jpg" height="100px" width="100px"/></td>
        
        <td>wertzs</td>
        <td><button type="button" className="btn btn-success" data-toggle="modal" data-target="#myModal">Update</button></td>
        
        <div className="modal fade" id="myModal" role="dialog">
<div className="modal-dialog">

  <div className="modal-content">
    <div className="modal-header btn-primary" >
      <button type="button" className="close" data-dismiss="modal">&times;</button>
      <h4 className="modal-title">Update Profile</h4>
    </div>
    <div className="modal-body">
      <div className="panel-body">
                        <div className="form">
                            <form className="cmxform form-horizontal " id="signupForm" method="get" action="" novalidate="novalidate">
                                <div className="form-group " style="margin-bottom: 10px !important">
                                    <label for="name" className="control-label col-lg-6">Name</label>
                                    <div className="col-lg-6" style="margin-bottom: 10px !important">
                                        <input className=" form-control" id="name" name="name" type="text"/>
                                    </div>
                                </div>
                                <div className="form-group " style="margin-bottom: 10px !important">
                                    <label for="address" className="control-label col-lg-6">Email</label>
                                    <div className="col-lg-6" style="margin-bottom: 10px !important">
                                        <input className=" form-control" id="email" name="email" type="email"/>
                                    </div>
                                </div>
                                <div className="form-group " style="margin-bottom: 10px !important">
                                    <label for="name" className="control-label col-lg-6">Specialization</label>
                                    <div className="col-lg-6" style="margin-bottom: 10px !important">
                                        <input className=" form-control" id="spl" name="spl" type="text"/>
                                    </div>
                                </div>
                                 <div className="form-group " style="margin-bottom: 10px !important">
                                    <label for="name" className="control-label col-lg-6">Mobile</label>
                                    <div className="col-lg-6" style="margin-bottom: 10px !important">
                                        <input className=" form-control" id="mob" name="mob" type="text"/>
                                    </div>
                                </div>
                                
                                <div className="form-group " style="margin-bottom: 10px !important">
                                    <label for="photo" className="control-label col-lg-6">Photo</label>
                                    <div className="col-lg-6" style="margin-bottom: 10px !important">
                                        <input className="form-control " id="photo" name="photo" type="file"/>
                                    </div>
                                </div>
                                
                                 <div className="form-group " style="margin-bottom: 10px !important">
                                    <label for="name" className="control-label col-lg-6">Password</label>
                                    <div className="col-lg-6" style="margin-bottom: 10px !important">
                                        <input className=" form-control" id="psw" name="psw" type="password"/>
                                    </div>
                                </div>
                                
                                
                               
                               

                                <div className="form-group">
                                    <div className="col-lg-offset-3 col-lg-6">
                                        <button className="btn btn-primary" type="submit">Save</button>
                                       
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
    </div>
    <div className="modal-footer" style="background-color:green">
      <button type="button" className="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
  
</div>
</div>
        
        
        
      </tr>
      
     
      
    </tbody>
  </table>
</div>
</div>
</div>
    
    
    
        

</section>
<div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>
    </div>
        </>)
}
export default Profile;