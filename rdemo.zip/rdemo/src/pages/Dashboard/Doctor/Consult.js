import { render } from "@testing-library/react"

const Consult=()=>{
    render(<> 
    
    <div>
      <section id="main-content">
    <section className="wrapper">
		
        <div className="form-w3layouts">
               
             
                <div className="row">
                    <div className="col-lg-12">
                        <section className="panel">
                            <header className="panel-heading">
                                Making Bill
                                
                            </header>
    <div className="table-responsive">
          <table className="table" ui-jq="footable" ui-options='{
            "paging": {
              "enabled": true
            },
            "filtering": {
              "enabled": true
            },
            "sorting": {
              "enabled": true
            }}'>
            <thead>
              <tr>
                <th data-breakpoints="xs">ID</th>
                <th>Patient Name</th>
                <th>Mobile</th>
                <th>Health Description</th>
                <th>Medicine</th>
                
    
                
              </tr>
            </thead>
            <tbody>
              <tr data-expanded="true">
                <td>1</td>
                <td>Saurabh Jadhav</td>
                <td>8999967626</td>
                <td>The default format of the timestamp contained in the string is yyyy-mm-dd hh:mm:ss. However, you can specify an optional format string defining </td>
                <td>The timestamp format is the date format and the time format combined</td>
                
                
              </tr>
              
              <tr data-expanded="true">
                <td>1</td>
                <td>Saurabh Jadhav</td>
                <td>8999967626</td>
                <td>The default format of the timestamp contained in the string is yyyy-mm-dd hh:mm:ss. However, you can specify an optional format string defining </td>
                <td>The timestamp format is the date format and the time format combined</td>
                
                
              </tr>
              
              <tr data-expanded="true">
                <td>1</td>
                <td>Saurabh Jadhav</td>
                <td>8999967626</td>
                <td>The default format of the timestamp contained in the string is yyyy-mm-dd hh:mm:ss. However, you can specify an optional format string defining </td>
                <td>The timestamp format is the date format and the time format combined</td>
                
                
              </tr>
              
              <tr data-expanded="true">
                <td>1</td>
                <td>Saurabh Jadhav</td>
                <td>8999967626</td>
                <td>The default format of the timestamp contained in the string is yyyy-mm-dd hh:mm:ss. However, you can specify an optional format string defining </td>
                <td>The timestamp format is the date format and the time format combined</td>
                
                
              </tr>
            </tbody>
          </table>
        </div>                    </section>
                    </div>
                </div>
            </div>
            
            
            
                
        
    </section>
    <div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>
        
        </div></>)
}
export default Consult;