import { render } from "@testing-library/react"

const Add_Dr=()=>{
    render(<> 
    <div>
        <section id="main-content">
    <section className="wrapper">
		
        <div className="form-w3layouts">
               
             
                <div className="row">
                    <div className="col-lg-12">
                        <section className="panel">
                            <header className="panel-heading">
                                Add Doctors
                                
                            </header>
                            <div className="panel-body">
                                <div className="form">
                                    <form className="cmxform form-horizontal " id="signupForm" method="get" action="" novalidate="novalidate">
                                        <div className="form-group ">
                                            <label for="name" className="control-label col-lg-3">Doctor Name</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="name" name="name" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="mobile" className="control-label col-lg-3">Mobile</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="mob" name="mob" type="text"/>
                                            </div>
                                        </div>
                                       
                                        <div className="form-group ">
                                            <label for="email" className="control-label col-lg-3">Email</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="email" name="email" type="email"/>
                                            </div>
                                        </div>
                                        
                                        <div className="form-group ">
                                            <label for="Specialization" className="control-label col-lg-3">Specialization</label>
                                            <div className="col-lg-6">
                                                <input className=" form-control" id="special" name="special" type="text"/>
                                            </div>
                                        </div>
                                        <div className="form-group ">
                                            <label for="photo" className="control-label col-lg-3">Photo</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="photo" name="photo" type="file"/>
                                            </div>
                                        </div>
    
                                        <div className="form-group ">
                                            <label for="password" className="control-label col-lg-3">Password</label>
                                            <div className="col-lg-6">
                                                <input className="form-control " id="password" name="password" type="password"/>
                                            </div>
                                        </div>
                                       
                                       
    
                                        <div className="form-group">
                                            <div className="col-lg-offset-3 col-lg-6">
                                                <button className="btn btn-primary" type="submit">Save</button>
                                               
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            
            
            
                
        
    </section>
    <div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>
    </div>
    </>)
}
export default Add_Dr;