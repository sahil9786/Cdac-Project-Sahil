import { render } from "@testing-library/react"

const Patient_Bill=()=>{
    render(<> 
    <div>
      <section id="main-content">
    <section className="wrapper">
		
		
        <div className="table-agile-info">
<div className="panel panel-default">
<div className="panel-heading">
 Patient Bill Details
</div>
<div>
  <table className="table" ui-jq="footable" ui-options='{
    "paging": {
      "enabled": true
    },
    "filtering": {
      "enabled": true
    },
    "sorting": {
      "enabled": true
    }}'>
    <thead>
      <tr>
        <th data-breakpoints="xs">ID</th>
        <th>Patient Name</th>
        <th>Mobile</th>
        <th>Date</th>
        <th>Health Issue</th>
        <th>Medicine</th>
        <th >Bill Status</th>
        
      </tr>
    </thead>
    <tbody>
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>2011-02-11</td>
        <td>creates a responsive table. The table will then scroll horizontally on small devices (under 768px). When viewing on anything larger than 768px wide, there is no difference</td>
        <td>Indicates a dangerous or potentially negative action</td>
        <td>Paid</td>
        
      </tr>
      
     <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>2011-02-11</td>
        <td>creates a responsive table. The table will then scroll horizontally on small devices (under 768px). When viewing on anything larger than 768px wide, there is no difference</td>
        <td>Indicates a dangerous or potentially negative action</td>
        <td>Paid</td>
        
      </tr>
      
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>2011-02-11</td>
        <td>creates a responsive table. The table will then scroll horizontally on small devices (under 768px). When viewing on anything larger than 768px wide, there is no difference</td>
        <td>Indicates a dangerous or potentially negative action</td>
        <td>Paid</td>
        
      </tr>
      
      <tr data-expanded="true">
        <td>1</td>
        <td>Saurabh Jadhav</td>
        <td>8999967626</td>
        <td>2011-02-11</td>
        <td>creates a responsive table. The table will then scroll horizontally on small devices (under 768px). When viewing on anything larger than 768px wide, there is no difference</td>
        <td>Indicates a dangerous or potentially negative action</td>
        <td>Paid</td>
        
      </tr>
        
      
    </tbody>
  </table>
</div>
</div>
</div>
    
    
    
        

</section>
<div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>
    </div>
    </>)
}
export default Patient_Bill;