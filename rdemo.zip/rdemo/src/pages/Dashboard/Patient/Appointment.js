import { render } from "@testing-library/react"

const Appointment=()=>{
    render(<> 
    <div>
        <section id="main-content">
    <section className="wrapper">
		
		
        <div className="table-agile-info">
<div className="panel panel-default">
<div className="panel-heading">
Approval Of Appointment    </div>
<div className="panel-body">
                        <div className="form">
                            <form className="cmxform form-horizontal " id="signupForm" method="get" action="" novalidate="novalidate">
                                <div className="form-group ">
                                    <label for="name" className="control-label col-lg-3">Patient Name</label>
                                    <div className="col-lg-6">
                                        <input className=" form-control" id="name" name="name" type="text"/>
                                    </div>
                                </div>
                                <div className="form-group ">
                                    <label for="mobile" className="control-label col-lg-3">Mobile</label>
                                    <div className="col-lg-6">
                                        <input className=" form-control" id="mob" name="mob" type="text"/>
                                    </div>
                                </div>
                               <div className="form-group ">
                                    <label for="name" className="control-label col-lg-3">Hospital Name</label>
                                    <div className="col-lg-6">
                                        <select id="hospital" name="hospital">
                                          <option value="Minakshi">Minakshi Hospital</option>
                                          <option value="Satara">Satara Hospital</option>
                                          <option value="Sahyadri">Sahyadri Hospital</option>
                                          <option value="Shwas">Shwas Hospital</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div className="form-group ">
                                    <label for="name" className="control-label col-lg-3">Doctor Name</label>
                                    <div className="col-lg-6">
                                        <select id="dr" name="dr">
                                          <option value="1">Dr. bhosale S. V.</option>
                                          <option value="2">Dr. nikam S. V.</option>
                                          <option value="3">Dr. lawand S. V.</option>
                                          <option value="4">Dr. deshpande S. V.</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="form-group ">
                                    <label for="date" className="control-label col-lg-3">Date</label>
                                    <div className="col-lg-6">
                                        <input className="form-control " id="date" name="date" type="datetime-local"/>
                                    </div>
                                </div>
                                
                                
                               
                               

                                <div className="form-group">
                                    <div className="col-lg-offset-3 col-lg-6">
                                        <button className="btn btn-primary" type="submit">Save</button>
                                       
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
</div>
</div>
    
    
    
        

</section>
<div className="footer">
			<div className="wthree-copyright">
			  <p>© 2021 IACSD Akurdi PUNE</p></div>
		  </div>
          <script src="assets/dassets/js/bootstrap.js"></script>
<script src="assets/dassets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="assets/dassets/js/scripts.js"></script>
<script src="assets/dassets/js/jquery.slimscroll.js"></script>
<script src="assets/dassets/js/jquery.nicescroll.js"></script>
<script src="assets/dassets/js/jquery.scrollTo.js"></script>
</section>
    </div>
    </>)
}
export default Appointment;