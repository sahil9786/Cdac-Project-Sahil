import React from "react";
import { BrowserRouter,Route, Link, Switch } from "react-router-dom";
import { Redirect } from "react-router";
import Bill from "./Bill";
import Appointment_Status from "./Appointment";
import Profile from "./Profile";


const ReceptionMain=()=>{
    
    return(
            <BrowserRouter>
            <div>
            <header className="header fixed-top clearfix">
<div className="brand">
    <a href="#" className="logo">
        Reception
    </a>
    <div className="sidebar-toggle-box">
        <div className="fa fa-bars"></div>
    </div>
</div>

<div className="top-nav clearfix">
    
    <ul className="nav pull-right top-menu">
       
       
        <li className="dropdown">
            <a data-toggle="dropdown" className="dropdown-toggle" href="#">
                <img alt="" src="images/2.png"/>
                <span className="username">John Doe</span>
                <b className="caret"></b>
            </a>
            <ul className="dropdown-menu extended logout">
               
                
                <li><Link to="/home"><i className="fa fa-key"></i> Log Out</Link></li>
            </ul>
        </li>
        
       
    </ul>
    
</div>
</header>

<aside>
    <div id="sidebar">
      
        <div className="leftside-navigation">
            <ul className="sidebar-menu" id="nav-accordion">
                <li>
                    <a className="active" href="#">
                        <i className="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li>
                    <Link to="/bill">
                        <i className="fa fa-bullhorn"></i>
                        <span>Bill Status</span>
                    </Link>
                </li>
                <li>
                    <Link to="/appointment_status">
                        <i className="fa fa-bullhorn"></i>
                        <span>Appointment Status</span>
                    </Link>
                </li>
				<li>
                    <Link to="/profile">
                        <i className="fa fa-bullhorn"></i>
                        <span>Update Profile</span>
                    </Link>
                </li>
               
               
                
            </ul>            </div>
       
    </div>
</aside>
<div> 
<Switch>
<Route exact path="/"><Redirect to="/bill" /></Route>
	<Route exact path="/bill"component={Bill}></Route>
	<Route exact path="/appointment_status"component={Appointment_Status}></Route>
	<Route exact path="/profile"component={Profile}></Route>	
</Switch>
	</div>
            </div>
            </BrowserRouter>
        )
        
            

        
    }

export default ReceptionMain;