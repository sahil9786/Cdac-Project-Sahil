
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import './App.css';
import Main from './pages/main';
import { Redirect } from 'react-router';
import AdminMain from './pages/Dashboard/Admin/Main';

function App() {
  return(
    <Main/>
  );
}

export default App;
