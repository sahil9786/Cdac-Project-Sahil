package com.hsm.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient")
public class Patient {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pid;
	private String name;
	private String address;
	private int adhar;
	private int mobile; 
	
	public Patient() {
		// TODO Auto-generated constructor stub
	}

	public Patient(int pid, String name, String address, int adhar, int mobile) {
		super();
		this.pid = pid;
		this.name = name;
		this.address = address;
		this.adhar = adhar;
		this.mobile = mobile;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAdhar() {
		return adhar;
	}

	public void setAdhar(int adhar) {
		this.adhar = adhar;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Patient [pid=" + pid + ", name=" + name + ", address=" + address + ", adhar=" + adhar + ", mobile="
				+ mobile + "]";
	}
	
	

						

}
