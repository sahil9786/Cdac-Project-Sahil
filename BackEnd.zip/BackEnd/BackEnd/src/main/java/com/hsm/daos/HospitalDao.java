package com.hsm.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hsm.entity.Hospital;

public interface HospitalDao extends JpaRepository<Hospital, Integer> {

}
