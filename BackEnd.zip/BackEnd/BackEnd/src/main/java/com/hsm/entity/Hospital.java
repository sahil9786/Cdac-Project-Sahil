package com.hsm.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "hospital")
public class Hospital {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hid;
	private String name;
	private String address;
	private int phone;
	@Transient
	private String description;
	
	@OneToOne(fetch =FetchType.EAGER,cascade = CascadeType.ALL )
	@JoinColumn(name = "userid")
	private Users user;
	
	public Hospital() {
		
	}

	

	public Hospital(int hid, String name, String address, int phone, String description, Users user) {
		super();
		this.hid = hid;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.description = description;
		this.user = user;
	}



	public int getHid() {
		return hid;
	}

	public void setHid(int hid) {
		this.hid = hid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Users getUser() {
		return user;
	}



	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Hospital [hid=" + hid + ", name=" + name + ", address=" + address + ", phone=" + phone
				+ ", description=" + description + "]";
	}
	
	
	
	
	

}
