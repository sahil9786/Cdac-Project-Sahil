package com.hsm.service;

import java.util.List;

import com.hsm.entity.Users;

public interface UserService {

	Users findByEmail(String uname);

	List<Users> getUsers();

}
