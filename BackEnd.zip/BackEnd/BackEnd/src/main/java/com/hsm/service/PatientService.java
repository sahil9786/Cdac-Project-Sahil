package com.hsm.service;

public interface PatientService {

}
