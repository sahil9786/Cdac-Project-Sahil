package com.hsm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsm.daos.PatientDao;
import com.hsm.entity.Hospital;
import com.hsm.entity.Patient;

@Service
@Transactional
public class PatientServiceImpl implements PatientService  {
	
	@Autowired
	private PatientDao patientDao;

	public List<Patient> getAll() {
		return patientDao.findAll();
	}

}
