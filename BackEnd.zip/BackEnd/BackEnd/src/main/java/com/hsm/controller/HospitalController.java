package com.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hsm.entity.Doctor;
import com.hsm.entity.Hospital;
import com.hsm.service.HospitalServiceImpl;
import com.hsm.utils.Response;

@CrossOrigin
@RestController
public class HospitalController {
	
		

}
