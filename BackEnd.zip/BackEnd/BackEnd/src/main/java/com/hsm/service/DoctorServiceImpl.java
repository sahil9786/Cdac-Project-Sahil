package com.hsm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsm.daos.DoctorDao;
import com.hsm.entity.Doctor;


@Service
@Transactional	
public class DoctorServiceImpl implements DoctorService {
	
	@Autowired
	private DoctorDao doctorDao;

	public List<Doctor> getAll() {
		return doctorDao.findAll();
	}

}
