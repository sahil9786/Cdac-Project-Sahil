package com.hsm.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hsm.entity.Patient;

public interface PatientDao extends JpaRepository<Patient, Integer> {

}
