package com.hsm.service;

public interface HospitalService {

}
